exports.port=3000
exports.user='eswari'
exports.password='test@123'
exports. authdb='admin'
exports.url='127.0.0.1'
exports.mongodb='expressdb'
exports.mongoport=27017


