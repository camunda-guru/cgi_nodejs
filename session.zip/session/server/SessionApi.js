/**
 * Created by BALASUBRAMANIAM on 24-03-2017.
 */
var express = require('express');
var session = require('express-session');
var mongoose = require('mongoose');
MongoStore = require('connect-mongo')(session)
var bodyParser =require("body-parser");
var config=require('./config');
var cors=require("cors");
app = express();
app.use(cors());

app.use(bodyParser.json({ type: 'application/*+json' }))
var options = {
    user: config.user,
    pass: config.password,
    auth: {
        authdb: config.authdb
    }
}

mongoose.connect(config.url, config.mongodb,
    config.mongoport, options);


app.use(session({
    secret: '2C44-4D44-WppQ38S',

    store: new MongoStore({
        mongooseConnection: mongoose.connection
    }),
    activeDuration: 5 * 60 * 1000,
    httpOnly: true,
    secure: true,
    ephemeral: true,

    saveUninitialized : false

}));

// Authentication and Authorization Middleware
var auth = function(req, res, next) {
    if (req.session && req.session.userId === "admin" && req.session.pssword === "admin123")
        return next();
    else
        return res.sendStatus(401);
};

app.post('/login',function(req,res)
{
    console.log("Testing...")
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:63342');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
    res.header("Access-Control-Allow-Headers", "X-Requested-With, Content-Type");
    res.setHeader('Access-Control-Allow-Credentials', true);
    console.dir(req.query);
    if((!req.query.userId)&&(!req.query.password))
        res.end('Login Failed');
    else
    {


        var hour = 3600000;
        req.session.cookie.expires = new Date(Date.now() + hour)
        req.session.cookie.maxAge = hour
        req.session.userId=req.query.userId;
        req.session.password=req.query.password;

        res.end(req.sessionID);

    }


});

// Logout endpoint
app.get('/logout', function (req, res) {
    req.session.destroy();
    res.send("logout success!");
});


app.set('port',config.port);

app.listen(app.get('port'),function()
{
    console.log("Server started....@"+app.get('port'));
});