/**
 * Created by BALASUBRAMANIAM on 04-04-2017.
 */
var userModule = angular.module('UserModule',['ngMessages','ngMaterial','ngMdIcons']);

userModule.controller('RegCtrl',['$scope','$mdDialog','$interval',function($scope,$mdDialog,$interval)
{


}]);

