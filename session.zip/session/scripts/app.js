/**
 * Created by BALASUBRAMANIAM on 24-03-2017.
 */
userModule=angular.module('UserModule',['ngRoute','ngMaterial','ngMdIcons','ServiceModule']);



userModule.config(function ($routeProvider, $locationProvider) {

    $routeProvider

        .when('/homePage/:userId', {
            templateUrl: 'Home.html',
            controller:'homeCtrl'
        }
    )
        .when('/search/:sId', {
            templateUrl: 'Search.html',
            controller: 'searchCtrl'
        }
    )
        .
        otherwise({
            redirectTo: '/home'
        });

});




userModule.controller('userCtrl',['$scope','loginService',
    '$location','$rootScope',
    function($scope,loginService,$location,$rootScope)
{
    /*
    $scope.roleIsX="";
    $scope.$on("$locationChangeStart", function(event, next, current) {
        if (!$scope.roleIsX) {
            event.preventDefault();
        }
    });
*/
$scope.currentPage = true;
   $scope.userData={
       userId:'',
       password:''
   }
    $scope.login=function()
    {
        console.log($scope.userData);
        loginService.sendLoginDataObj($scope.userData).then(function(response)
        {
           console.log(response.data);
            if(response.data.search('Login') == -1) {
                $scope.currentPage = false;
                $location.path('/homePage/'+$scope.userData.userId);
            }


        });
    }


}]);

userModule.controller('homeCtrl',['$scope','$routeParams',
    function($scope,$routeParams)
{

    console.log($routeParams.userId);
    $scope.userName=$routeParams.userId;
}])

userModule.controller('searchCtrl',['$scope',function($scope)
{

}])