/**
 * Created by BALASUBRAMANIAM on 01-04-2017.
 */
/**
 * Created by BALASUBRAMANIAM on 28-03-2017.
 */
var userModule = angular.module('UserModule',['ngMessages','ngMaterial','ngMdIcons']);

userModule.controller('RegCtrl',['$scope','$mdDialog','$interval',function($scope,$mdDialog,$interval)
{
    $scope.user={
        firstName:"",
        lastName:"",
        gender:0
    }
  $scope.rowspan="";
  $scope.noOfPassengers=2;
    if( $scope.noOfPassengers<=5)
      $scope.rowspan="3";
    else
        $scope.rowspan="6";
    console.log($scope.rowspan);
    $scope.dataArray=[];
for(i=0;i<$scope.noOfPassengers;i++)
    $scope.dataArray.push($scope.user);

    console.log($scope.dataArray);



   $scope.submit=function()
   {
       console.log($scope.dataArray);
   }

}]);

