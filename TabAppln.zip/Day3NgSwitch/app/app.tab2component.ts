/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
import { Component, Input } from '@angular/core';
import {Http} from '@angular/http';
import 'rxjs/Rx';

@Component({
    selector: 'app-tab-content',
    templateUrl: 'app/app.component.html',
    styles: [`
    :host {
      border: 1px solid #ddd;
      border-top: 0;
      margin-bottom: 2rem;
      display: block;
      padding: 8px;
    }
  `]
})
export class TabContentComponent {
    private users = [];
    @Input() tabposition:number;
    exists = false;
    httpObj;


    constructor(http: Http) {
        this.httpObj=http;

    }

    CallRest()
    {
        console.log(this.tabposition);
        switch(this.tabposition)
        {
            case 1:
                this.httpObj.get('http://jsonplaceholder.typicode.com/users/')
                    .flatMap((data) => data.json())
                    .subscribe((data) => {
                        this.users.push(data);
                    });
                break;
            case 2:
                this.httpObj.get('http://jsonplaceholder.typicode.com/albums/')
                    .flatMap((data) => data.json())
                    .subscribe((data) => {
                        this.users.push(data);
                    });
                break;
            case 3:
                this.httpObj.get('http://jsonplaceholder.typicode.com/posts/')
                    .flatMap((data) => data.json())
                    .subscribe((data) => {
                        this.users.push(data);
                    });
                break;

        }


    }
    generateArray(obj){
        return Object.keys(obj).map((key)=>{ return obj[key]});
    }

    toggleExists()
    {

        this.exists=!this.exists;
        if(this.exists)
            this.CallRest();
        else
            this.users=[];
    }
}