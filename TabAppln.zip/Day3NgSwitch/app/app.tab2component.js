"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
var core_1 = require('@angular/core');
require('rxjs/Rx');
var TabContentComponent = (function () {
    function TabContentComponent(http) {
        this.users = [];
        this.exists = false;
        this.httpObj = http;
    }
    TabContentComponent.prototype.CallRest = function () {
        var _this = this;
        console.log(this.tabposition);
        switch (this.tabposition) {
            case 1:
                this.httpObj.get('http://jsonplaceholder.typicode.com/users/')
                    .flatMap(function (data) { return data.json(); })
                    .subscribe(function (data) {
                    _this.users.push(data);
                });
                break;
            case 2:
                this.httpObj.get('http://jsonplaceholder.typicode.com/albums/')
                    .flatMap(function (data) { return data.json(); })
                    .subscribe(function (data) {
                    _this.users.push(data);
                });
                break;
            case 3:
                this.httpObj.get('http://jsonplaceholder.typicode.com/posts/')
                    .flatMap(function (data) { return data.json(); })
                    .subscribe(function (data) {
                    _this.users.push(data);
                });
                break;
        }
    };
    TabContentComponent.prototype.generateArray = function (obj) {
        return Object.keys(obj).map(function (key) { return obj[key]; });
    };
    TabContentComponent.prototype.toggleExists = function () {
        this.exists = !this.exists;
        if (this.exists)
            this.CallRest();
        else
            this.users = [];
    };
    __decorate([
        core_1.Input()
    ], TabContentComponent.prototype, "tabposition");
    TabContentComponent = __decorate([
        core_1.Component({
            selector: 'app-tab-content',
            templateUrl: 'app/app.component.html',
            styles: ["\n    :host {\n      border: 1px solid #ddd;\n      border-top: 0;\n      margin-bottom: 2rem;\n      display: block;\n      padding: 8px;\n    }\n  "]
        })
    ], TabContentComponent);
    return TabContentComponent;
}());
exports.TabContentComponent = TabContentComponent;
//# sourceMappingURL=app.tab2component.js.map