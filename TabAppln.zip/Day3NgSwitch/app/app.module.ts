/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
import { BrowserModule }  from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { TabComponent  } from './app.tab1component';
import {TabContentComponent } from './app.tab2component';
@NgModule({
    imports: [BrowserModule,HttpModule],
    declarations: [AppComponent,
        TabComponent,
        TabContentComponent
    ],
    bootstrap: [AppComponent]
})
export class MyAppModule {

}
