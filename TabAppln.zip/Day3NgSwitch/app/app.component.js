"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
var core_1 = require('@angular/core');
var AppComponent = (function () {
    function AppComponent() {
        this.tab = 1;
    }
    AppComponent.prototype.setTab = function (num) {
        this.tab = num;
    };
    AppComponent.prototype.isSelected = function (num) {
        return this.tab === num;
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'app-root',
            template: "\n    <div class=\"tabs-selection\">\n      <app-tab [active]=\"isSelected(1)\" (click)=\"setTab(1)\">Users</app-tab>\n      <app-tab [active]=\"isSelected(2)\" (click)=\"setTab(2)\">Albums</app-tab>\n      <app-tab [active]=\"isSelected(3)\" (click)=\"setTab(3)\">Photos</app-tab>\n    </div>\n\n    <div [ngSwitch]=\"tab\">\n      <app-tab-content *ngSwitchCase=\"1\" [tabposition]=\"tab\">  </app-tab-content>\n      <app-tab-content *ngSwitchCase=\"2\" [tabposition]=\"tab\"> </app-tab-content>\n      <app-tab-content *ngSwitchCase=\"3\" [tabposition]=\"tab\"> </app-tab-content>\n      <app-tab-content *ngSwitchDefault> </app-tab-content>\n    </div>\n  ",
            styles: ["\n    :host {\n      font-family: Arial;\n    }\n\n    .tabs-selection {\n      background-color: #ddd;\n      display: flex;\n      box-sizing: border-box;\n      flex-direction: row;\n      padding-left: 16px;\n      padding-right: 16px;\n      width: 100%;\n    }\n  "]
        })
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map