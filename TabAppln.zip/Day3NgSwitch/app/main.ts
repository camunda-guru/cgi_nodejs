/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic'
import { MyAppModule } from './app.module'

platformBrowserDynamic().bootstrapModule(MyAppModule)
