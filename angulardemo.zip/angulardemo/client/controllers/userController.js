/**
 * Created by BALASUBRAMANIAM on 11/09/2017.
 */
mainApp.controller('UserController',['$scope','$http',function($scope,$http)
{
    $scope.user={
        clientName:"",
        location:""
    }

    $http({
        url:'https://www.quandl.com/api/v3/datasets/BOF/QS_M_IEUTIO9M.json?auth_token=nHYufVSHw4383Wy4_Ekg',
        method:'get',
        datatype:'json',
        headers:{
            'Content-Type':'application/json'
        }
    }).then(function successCallback(response) {
        // this callback will be called asynchronously
        // when the response is available
        console.log(response);
    }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
        console.log(response);
    })


    $scope.save=function()
    {
        console.log($scope.user);
    }

}])