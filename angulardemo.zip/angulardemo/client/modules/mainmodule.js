/**
 * Created by BALASUBRAMANIAM on 11/09/2017.
 */
var mainApp=angular.module('MainApp',[]);
mainApp.config(['$httpProvider', function($httpProvider) {
    $httpProvider.defaults.useXDomain = true;
    delete $httpProvider.defaults.headers.common['X-Requested-With'];
}
]);