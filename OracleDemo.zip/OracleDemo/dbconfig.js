exports.user='system'
exports.password='vignesh'
exports.connectString='localhost/XE'

