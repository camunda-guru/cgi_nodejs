var express =require('express');
var bodyParser=require('body-parser');
var config=require('./configuration');
var conn=require('../testconnection');

var app =new express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

//routes
app.get('/connect',function(request,response)
{
    response.setHeader('Access-Control-Allow-Origin','*');
    response.setHeader('Access-Control-Allow-Methods','GET','POST');
    response.setHeader('Access-Control-Allow-Headers','X-Requested-With,Content-Type');//Tells in which format i am sendingdata
    response.setHeader('Access-Control-Allow-Credentials',true);
    conn.createPool().then(function(data)
    {
        response.send(data);
    }).catch(function(err) {
    console.error('Error occurred creating database connection pool', err);
    console.log('Exiting process');
    process.exit(0);
});
})

app.get('/disconnect',function(request,response)
{
    response.setHeader('Access-Control-Allow-Origin','*');
    response.setHeader('Access-Control-Allow-Methods','GET','POST');
    response.setHeader('Access-Control-Allow-Headers','X-Requested-With,Content-Type');//Tells in which format i am sendingdata
    response.setHeader('Access-Control-Allow-Credentials',true);
    conn.terminatePool().then(function(data)
    {
        response.send(data);
    }).catch(function(err) {
        console.error('Error occurred creating database connection pool', err);
        console.log('Exiting process');
        process.exit(0);
    });
})
app.get('/getconnect',function(request,response)
{
    response.setHeader('Access-Control-Allow-Origin','*');
    response.setHeader('Access-Control-Allow-Methods','GET','POST');
    response.setHeader('Access-Control-Allow-Headers','X-Requested-With,Content-Type');//Tells in which format i am sendingdata
    response.setHeader('Access-Control-Allow-Credentials',true);
    conn.getConnection().then(function(data)
    {
        response.send(data);
    }).catch(function(err) {
        console.error('Error occurred creating database connection pool', err);
        console.log('Exiting process');
        process.exit(0);
    });
})

app.get('/getTraders',function(request,response)
{
    response.setHeader('Access-Control-Allow-Origin','*');
    response.setHeader('Access-Control-Allow-Methods','GET','POST');
    response.setHeader('Access-Control-Allow-Headers','X-Requested-With,Content-Type');//Tells in which format i am sendingdata
    response.setHeader('Access-Control-Allow-Credentials',true);
    conn.simpleExecute("select * from irs.trader").then(function(data)
    {
        response.send(data);
    }).catch(function(err) {
        console.error('Error occurred creating database connection pool', err);
        console.log('Exiting process');
        process.exit(0);
    });


})

app.get('/getTraderById',function(request,response)
{
    response.setHeader('Access-Control-Allow-Origin','*');
    response.setHeader('Access-Control-Allow-Methods','GET','POST');
    response.setHeader('Access-Control-Allow-Headers','X-Requested-With,Content-Type');//Tells in which format i am sendingdata
    response.setHeader('Access-Control-Allow-Credentials',true);
    var searchId=57;
    conn.paramExecute("select * from irs.trader where  TraderId =:id",{id: searchId}).then(function(data)
    {
        response.send(data);
    }).catch(function(err) {
        console.error('Error occurred creating database connection pool', err);
        console.log('Exiting process');
        process.exit(0);
    });
})

app.get('/getMultipleTables',function(request,response)
{
    response.setHeader('Access-Control-Allow-Origin','*');
    response.setHeader('Access-Control-Allow-Methods','GET','POST');
    response.setHeader('Access-Control-Allow-Headers','X-Requested-With,Content-Type');//Tells in which format i am sendingdata
    response.setHeader('Access-Control-Allow-Credentials',true);

    var sql=[];
    sql.push("select * from irs.trader");
    sql.push("select * from irs.bank");
    sql.push("select * from irs.currency");
    sql.push("select * from irs.deal");
    conn.logQueries(sql).then(function(data)
    {
       response.send(data);
    }).catch(function(err) {
        console.error('Error occurred creating database connection pool', err);
        console.log('Exiting process');
        process.exit(0);
    });

})
app.listen(config.port,function()
{
    console.log('server is up'+config.port);
})
