var oracledb = require('oracledb');
var async = require('async');

var queries = [];
var idx;

function getQueries (count) {
    var queries = [];

    for (idx = 0; idx < count; idx += 1) {
        queries[idx] = {
            id: idx,
            name: "Thing number " + idx
        };
    }

    return queries;
}

queries = getQueries(500);
oracledb.getConnection(
    {
        user          : "System",
        password      : "vignesh",
        connectString : "localhost/XE"
    },
    function(err, connection)
    {
        var ids = [];
        var names = [];
        var start = Date.now();

        if (err) {throw err;}

        // We need to break up the array of JavaScript objects into arrays that
        // work with node-oracledb bindings.
        for (idx = 0; idx < queries.length; idx += 1) {
            ids.push(queries[idx].id);
            names.push(queries[idx].name);
        }

        connection.execute(
            ` declare
        type number_aat is table of number
          index by pls_integer;
        type varchar2_aat is table of varchar2(50)
          index by pls_integer;

        l_ids   number_aat := :ids;
        l_names varchar2_aat := :names;
      begin
        forall x in l_ids.first .. l_ids.last
          insert into irs.testquery (id, name) values (l_ids(x), l_names(x));
      end;`,
            {
                ids: {
                    type: oracledb.NUMBER,
                    dir: oracledb.BIND_IN,
                    val: ids
                },
                names: {
                    type: oracledb.STRING,
                    dir: oracledb.BIND_IN,
                    val: names
                }
            },
            {
                autoCommit: true
            },
            function(err) {
                if (err) {console.log(err); return;}

                console.log('Success. Inserted ' + queries.length + ' rows in ' + (Date.now() - start) + ' ms.');
            }
        );
    });

// Release the connection
function doRelease(connection)
{
    connection.release(
        function(err) {
            if (err) { console.error(err.message); }
        });
}